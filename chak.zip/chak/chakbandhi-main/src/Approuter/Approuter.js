import React, { useContext, useEffect } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "../Pages/Login/Login";
import MainLayout from "../MainLayout/MainLayout";
import ErrorPage from "../Pages/ErrorPage/ErrorPage";
import LandParcel from "../Pages/LandParcel/LandParcel";
import Tehsil from "../Pages/Tehsil/Tehsil";
import CHForms from "../Pages/CHForms/CHForms";
import Feedback from "../Pages/Feedback/Feedback";
import MapDetails from "../Components/MapDetails/MapDetails";
import { ThemeProvider } from "@mui/material";
import { UserCredsContext } from "../ContextApi/UserCredsContext/UserCredsContext";
import TestChForms from "../Pages/TestChForms/TestChForms";
import FormList from "../Pages/FormList/FormList";
import ChTwoForm from "../Pages/ChTwoForm/ChTwoForm";
import ChFourForm from "../Pages/ChFourForm/ChFourForm";
import LekhpalLayout from "../LekhpalLayout/LekhpalLayout";

function Approuter(props) {
  const { theme } = useContext(UserCredsContext);

  return (
    <div>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Login />} />

            <Route path="/dashboard" element={<MainLayout />}>
              {/* <Route index element={<TestPage />}></Route> */}
              <Route path="my-land-parcel" element={<LandParcel />} />
              <Route path="my-land-parcel/:id" element={<MapDetails />} />
              <Route path="my-tehsil" element={<Tehsil />} />
              <Route path="ch-forms" element={<CHForms />} />
              <Route path="feedback" element={<Feedback />} />
              <Route path="test-chform" element={<TestChForms />} />
            </Route>

            <Route path="/lekhpal" element={<LekhpalLayout />}>
              {/* <Route index element={<Login />} /> */}
              <Route path="forms" element={<FormList />} />
              <Route path="ch-2-form" element={<ChTwoForm />} />
              <Route path="ch-4-form" element={<ChFourForm />} />
              <Route path="*" element={<ErrorPage />} />
            </Route>

            <Route path="*" element={<ErrorPage />} />
          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </div>
  );
}

export default Approuter;
