export const panelList = [
  {
    title: "Land parcel",
    id: 1,
    url: "/dashboard/my-land-parcel",
  },
  // {
  //   title: "Tehsil",
  //   id: 2,
  //   url: "/dashboard/my-tehsil",
  // },
  // {
  //   title: "CH forms",
  //   id: 3,
  //   url: "/dashboard/ch-forms",
  // },
  // {
  //   title: "Feedback",
  //   id: 4,
  //   url: "/dashboard/feedback",
  // },
  {
    title: "Logout",
    id: 5,
    url: "/dashboard/logout",
  },
];

export const formField = [
  {
    name: "village",
    id: 1,
    label: "village",
  },
  {
    name: "pargana",
    id: 2,
    label: "pargana",
  },
  {
    name: "tahsil",
    id: 3,
    label: "tahsil",
  },
  {
    name: "district",
    id: 4,
    label: "district",
  },
  {
    name: "serial_number",
    id: 5,
    label: "serial number",
  },
  {
    name: "khatauni_khata",
    id: 6,
    label: "khatauni khata",
  },
  {
    name: "tenure_holder",
    id: 7,
    label: "tenure holder",
  },
  {
    name: "new_plot_number",
    id: 8,
    label: "new plot number",
  },
  {
    name: "area",
    id: 9,
    label: "area",
  },
  {
    name: "input1",
    id: 10,
    label: "input 1",
  },
  {
    name: "input2",
    id: 1,
    label: "input 2",
  },
  {
    name: "reult",
    id: 10,
    label: "result",
  },
];

export const districtOptions = [
  { title: "Ghazipur", id: 1 },
];

export const tehsilOptions = [
  { title: "Mohammadabad", id: 2 },
];

export const villageOptions = [
  { title: "Sherpur Dhotari", id: 3 },
];

export const statusType =[{
  name:"Lekhpal",
  id:1
},{
  name:"ACO",
  id:2
},{
  name:"CO",
  id:3
},{
  name:"SCO",
  id:4
},{
  name:"DM",
  id:5
}]
