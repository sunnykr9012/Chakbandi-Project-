import axios from "axios";

export var base_url = "http://13.233.168.11/";

export const _access_token = localStorage.getItem("chakbandhi_token");
var _headers =
  _access_token === null || _access_token === undefined
    ? {
        "Content-Type": "application/json",
      }
    : {
        "Content-Type": "application/json",
        Authorization: `Bearer ${_access_token}`,
      };

export var api_open = axios.create({
  baseURL: base_url,
  timeout: 300000000,
  headers: {
    "Content-Type": "application/json",
  },
  transformRequest: [
    function (data, headers) {
      return JSON.stringify(data);
    },
  ],
});

export var api_token = axios.create({
  baseURL: base_url,
  timeout: 300000000,
  headers: _headers,
  transformRequest: [
    function (data, headers) {
      return JSON.stringify(data);
    },
  ],
});

export function setToken(_token) {
  return new Promise((resolve, reject) => {
    try {
      localStorage.setItem("chakbandhi_token", _token);
      api_token = axios.create({
        baseURL: base_url,
        timeout: 300000000,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${_token}`,
          accept:
            "application/json;version=2, text/plain, */*, application/json, text/plain, */*",
        },
        transformRequest: [
          function (data, headers) {
            return JSON.stringify(data);
          },
        ],
      });

      resolve("Successfully set chakbandhi token.");
    } catch {
      reject("Error to set chakbandhi token");
    }
  });
}
