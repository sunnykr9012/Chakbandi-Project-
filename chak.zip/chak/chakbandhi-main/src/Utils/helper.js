export function reverseCoordinates(_array) {
  var cloneArray = JSON.parse(JSON.stringify(_array));
  console.log(cloneArray, "sandesh");

  var newArray = [];
  cloneArray.map((item) => {
    newArray.push(item.reverse());
  });

  return newArray;
}

export const helperDatefunction = (date_) => {
  const month = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const d = new Date(date_);
  let day = d.getDate();
  let name = month[d.getMonth()];
  let year = d.getFullYear();

  console.log("FFFF", day, name, year);

  return { day, name, year };
};
