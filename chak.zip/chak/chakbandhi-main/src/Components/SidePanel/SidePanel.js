import React, { useContext } from "react";
import styles from "./SidePanel.module.css";
import { useLocation, useNavigate } from "react-router-dom";
import { UserCredsContext } from "../../ContextApi/UserCredsContext/UserCredsContext";

function SidePanel({ panelList }) {
  const {logout} = useContext(UserCredsContext)
  let navigate = useNavigate();
  const handleRoute = (_item) => {
    if (_item.id === 5) {
      logout()
      navigate("/");
      return
    }
    navigate(_item.url);
  };
  return (
    <div className={styles.sidePanelC}>
      {panelList.map((item, index) => {
        return (
          <div
            className={`${styles.panelItem} ${
              index == 0 && styles.activeClass
            }`}
            key={index}
            onClick={() => handleRoute(item)}
          >
            {item.title}
          </div>
        );
      })}
    </div>
  );
}

export default SidePanel;
