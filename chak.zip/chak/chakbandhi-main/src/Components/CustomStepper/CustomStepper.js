import * as React from "react";
import Timeline from "@mui/lab/Timeline";
import TimelineSeparator from "@mui/lab/TimelineSeparator";
import TimelineConnector from "@mui/lab/TimelineConnector";
import TimelineContent from "@mui/lab/TimelineContent";
import TimelineDot from "@mui/lab/TimelineDot";
import TimelineItem, { timelineItemClasses } from "@mui/lab/TimelineItem";
import styles from "./CustomStepper.module.css";
import { statusType } from "../../Utils/constants";
import { helperDatefunction } from "../../Utils/helper";

export default function CustomStepper({ timeLine, ...props }) {
  return (
    <Timeline
      sx={{
        [`& .${timelineItemClasses.root}:before`]: {
          flex: 0,
          padding: 0,
        },
      }}
    >
      {getModules(timeLine)}
    </Timeline>
  );
}

const getModules = (timeLine) => {
  return timeLine.map((r, i) => {
    const className = i % 2 === 0 ? "custom-even-class" : "custom-odd-class";
    return (
      <TimelineItem classes={{ alignAlternate: className }} key={r.module_id}>
        <TimelineSeparator>
          <TimelineDot />
          {i !== timeLine.length - 1 && <TimelineConnector />}
        </TimelineSeparator>
        <TimelineContent>
          <div className={styles.cardC}>
            <h3 style={{ marginBottom: "10px", textTransform: "capitalize" }}>
              {r.form_name}
            </h3>
            <p style={{boxShadow: 'rgba(0, 0, 0, 0.05) 0px 0px 0px 1px',display:'inline-block',margin:"5px 0px" ,padding:"5px",borderRadius:"10px"}}>{statusType[r?.detail?.status - 1].name}</p>
            <p style={{ fontSize: "14px", color: "grey" }}>{r?.detail?.time}, {r?.detail?.date}</p>
          </div>
        </TimelineContent>
      </TimelineItem>
    );
  });
};
