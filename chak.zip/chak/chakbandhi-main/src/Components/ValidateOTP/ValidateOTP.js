import React, { useRef, useState } from "react";
import styles from "./Validate.module.css";

function ValidateOTP({ handleOTP }) {
  const list = [...Array(4).keys()];
  const [inputData, setInputData] = useState({
    phone: null,
    otp: [],
    isd_code: "",
  });
  const inputRef = useRef([]);
  const handleKeyChange = (e, idx) => {
    const next = inputRef;
    if (idx == 6) {
      return null;
    }
    if (idx == 0 && e.key !== "Backspace" && e.key !== "Delete") {
      return null;
    }
    if (e.key == "Delete" || e.key == "Backspace") {
      if (idx == 0) {
      } else {
        inputRef.current[idx - 1].focus();
      }
    }
  };
  const handler = (e, idx) => {
    const next = inputRef;
    const { value } = inputRef.current[idx];
    var otp_number = [...inputData.otp];
    otp_number[idx] = value;
    setInputData({ ...inputData, otp: otp_number });
    handleOTP(otp_number);
    if (value.length != 0 && idx < 3 && next) {
      next.current[idx + 1].focus();
    }
  };
  console.log(inputData, "inputData");
  return (
    <div>
      <div className={styles.otpInputField} style={{ width: "100%" }}>
        {list.map((x, id) => (
          <div key={id}>
            <input
              key={x}
              ref={(el: any) => (inputRef.current[x] = el)}
              onChange={(e) => handler(e, x)}
              onKeyUp={(e) => handleKeyChange(e, x)}
              type="text"
              className="otp_box"
              name={`otp_box${id}`}
              maxLength={1}
              style={{
                boxShadow: "0px 14px 25px rgba(42, 144, 189, 0.15)",
                border: "1px solid grey",
              }}
              // boxShadow: '0px 14px 25px rgba(221, 0, 0, 0.15)',
              // border:'1px solid #DD0000'
              // onBlur={() => handleValidation("otp")}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default ValidateOTP;
