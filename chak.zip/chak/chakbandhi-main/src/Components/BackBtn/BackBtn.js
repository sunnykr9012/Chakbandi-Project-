import React from "react";
import backbtn from "../../Assets/lekhpal/backBtn.png";
import { useNavigate } from "react-router-dom";
import styles from "./index.module.css";

const BackBtn = () => {
  let navigate = useNavigate();
  return (
    <div
      style={{ cursor: "pointer" }}
      className={styles.btn}
      onClick={() => {
        navigate("/lekhpal/forms");
      }}
    >
      <img src={backbtn} alt="back" />
    </div>
  );
};

export default BackBtn;
