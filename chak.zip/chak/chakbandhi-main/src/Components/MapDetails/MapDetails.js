import React, { useContext, useEffect, useState } from "react";
import MapComponent from "../MapComponent";
import InfoCard from "../InfoCard/InfoCard";
import styles from "./MapDetails.module.css";
import { agri, sherpur, sherpur_road } from "../../Utils/GeoJson";
import CustomStepper from "../CustomStepper/CustomStepper";
import { api_token } from "../../Utils/Network";
import { useParams } from "react-router-dom";

function MapDetails(props) {
  const { id } = useParams();
  const [landDetails, setLandDetails] = useState([]);
  const [issues, setIssues] = useState([]);
  console.log(issues, "issues");
  useEffect(() => {
    getData();
    getIssues();
  }, []);
  function getData() {
    api_token
      .get(`/geo/map/v1/plot/?plot_id=${id}`)
      .then((response) => {
        setLandDetails(response.data.data);
      })
      .catch((error) => {});
  }
  function getIssues() {
    api_token
      .get(`/geo/map/combined-form-data/${id}/`)
      .then((response) => {
        setIssues(response.data.data);
      })
      .catch((error) => {});
  }
  console.log(landDetails, "index");
  return (
    <div style={{ width: "100%", height: "90%" }}>
      {landDetails.map((item, index) => {
        return <InfoCard type={2} _data={item} />;
      })}{" "}
      <div className={styles.mapFlex} style={{ width: "100%", height: "650px" }}>
       <div></div>
        <div style={{ width: "80%" }}>
          <MapComponent agri={sherpur} id={id} agri1={sherpur_road} />
        </div>
        <div style={{ width: "18%", marginLeft: "auto" }}>
          <CustomStepper timeLine={issues} />
        </div>
      </div>
   
    </div>
  );
}

export default MapDetails;

const timeLine = [
  {
    title: "Land Consildation of Plot No. 00012 and Plot No. 00013",
    id: 1,
    date: "3rd October 2023, 2:34PM",
  },
  {
    title: "Land Consildation of Plot No. 00012 and Plot No. 00013",
    id: 1,
    date: "3rd October 2023, 2:34PM",
  },
  {
    title: "Land Consildation of Plot No. 00012 and Plot No. 00013",
    id: 1,
    date: "3rd October 2023, 2:34PM",
  },
];
