import React, { useContext, useEffect, useState } from "react";
import {
  MapContainer,
  TileLayer,
  GeoJSON,
  useMap,
  LayersControl,
  LayerGroup,
  Circle,
  FeatureGroup,
  Popup,
  Rectangle,
  Polygon,
  Polyline,
  ImageOverlay,
} from "react-leaflet";
import axios from "axios";
import L, { LatLngBounds } from "leaflet";
import GeometryUtil from "leaflet-geometryutil";
import CustomInput from "./CustomInput/CustomInput";
import { Button } from "@mui/material";
import CustomDrawer from "./CustomDrawer/CustomDrawer";
import { formField } from "./../Utils/constants";
// import { chform1, chform2 } from "./../Pages/TestChForms/TestChForms";
import styles from "./MapComponent.module.css";
import { reverseCoordinates } from "../Utils/helper";
import { UserCredsContext } from "../ContextApi/UserCredsContext/UserCredsContext";
import CustomDialog from "./CustomDialog/CustomDialog";
import { chform1, chform2 } from "../Pages/TestChForms/TestChForms";
import { api_token } from "../Utils/Network";
import { Map } from "react-leaflet";
import "esri-leaflet";

const center = [51.51, -0.06];
const rectangle = [
  [51.49, -0.08],
  [51.5, -0.06],
];
const multiPolygon = reverseCoordinates([
  [73.179340067101961, 23.694319153863983],
  [73.179298218875957, 23.694335525878767],
  [73.179265610850209, 23.694345874111658],
  [73.179074602525262, 23.694373522806924],
  [73.178992591813142, 23.694404753392043],
  [73.178980716487885, 23.694420711403229],
  [73.17898039747503, 23.694443704408709],
  [73.17900843226208, 23.694522989792365],
  [73.179065940319916, 23.694637883629163],
  [73.179084444957297, 23.694684094856282],
  [73.179083421269354, 23.694697880867988],
  [73.179074106592324, 23.694709269659427],
  [73.178946309134616, 23.694740728072738],
  [73.178927860531672, 23.694750476267618],
  [73.178927626578499, 23.694767337803764],
  [73.17892705795866, 23.694928308414411],
  [73.1789172966064, 23.694971887398651],
  [73.17889978940137, 23.695033772646614],
  [73.178883773817446, 23.695048148812774],
  [73.178881800830652, 23.69507035579543],
  [73.178895449953174, 23.695106544648993],
  [73.178899186026371, 23.695137250950967],
  [73.178866540784242, 23.695270248013664],
  [73.178860834492411, 23.695321540290109],
  [73.178878591920437, 23.695361610279047],
  [73.178888281661742, 23.695383187932944],
  [73.178974789788583, 23.695447830172657],
  [73.179173750976616, 23.695567071216587],
  [73.179217095542924, 23.695592877584609],
  [73.179238687353163, 23.695596581114447],
  [73.179249160148345, 23.695591721689304],
  [73.179285714357803, 23.695536959500306],
  [73.179289507528068, 23.695533554609586],
  [73.179296171197848, 23.695533249721858],
  [73.179301111800768, 23.695537140636166],
  [73.179316310197819, 23.695611675615535],
  [73.179343111407462, 23.695659900814199],
  [73.179357864125933, 23.695676555371261],
  [73.17937318716119, 23.695682101535859],
  [73.179408127610927, 23.695683662393979],
  [73.179431111414857, 23.695677033730632],
  [73.179454607048797, 23.695663512056505],
  [73.179602055289493, 23.695535698002757],
  [73.179631717117417, 23.695497718947035],
  [73.179645682278192, 23.695451123119629],
  [73.179652124895057, 23.695406738489073],
  [73.179636514554062, 23.695211848964615],
  [73.179635147618654, 23.695190369242138],
  [73.179600121338751, 23.695074973458265],
  [73.179606447008695, 23.695039019598333],
  [73.179614192758294, 23.695020713291942],
  [73.179647024166812, 23.694994269886411],
  [73.179693182844701, 23.694967216659926],
  [73.179710105034516, 23.694947485156007],
  [73.179715226335318, 23.694938346682523],
  [73.179723985057976, 23.694907020783376],
  [73.179731943374506, 23.694873385793468],
  [73.17975258799612, 23.694825335386792],
  [73.179783336998739, 23.694768971662768],
  [73.179791114593186, 23.694748366042944],
  [73.17978237394945, 23.694718367453746],
  [73.179744662633937, 23.694676529766603],
  [73.17972262664334, 23.694644841692813],
  [73.17971546556133, 23.694620994148249],
  [73.179719613189562, 23.694562017898399],
  [73.179733429384285, 23.694526152123306],
  [73.179729746268521, 23.69449161365911],
  [73.179715232786208, 23.694457714379286],
  [73.179657100785874, 23.694357761316283],
  [73.179655110421777, 23.694351222157078],
  [73.179652158632038, 23.694323974601815],
  [73.179644485764712, 23.694307020064851],
  [73.179619857326301, 23.69428220051827],
  [73.17960378187702, 23.694270896344083],
  [73.179579746560321, 23.694263331341155],
  [73.179560577400437, 23.694265022275275],
  [73.179495067523121, 23.694276899966415],
  [73.179386869169306, 23.69430571470453],
  [73.179340067101961, 23.694319153863983],
]);
const purpleOptions = { color: "purple" };
const redOptions = { color: "red" };
function setupEsriImagery() {
  console.log();
  return L.esri.tiledMapLayer({
    url: "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer",
  });
}
const MyData = ({ agri }) => {
  const [data, setData] = React.useState();
  const map = useMap();

  useEffect(() => {
    // const getData = async () => {
    //   const response = await axios.get(
    //     "https://gist.githubusercontent.com/UmairMughal901/d43ee77a9be27f2dcd006038fe8f07e7/raw/8650f4f3585ff0c1706da7a434251cfc70f1907b/map.geojson"
    //   );
    //   setData(response.data);
    // };
    // getData();
    setData(agri);
  }, [agri]);

  if (data) {
    // These next 3 lines purely for debuggins:
    const geojsonObject = L.geoJSON(data);

    map.fitBounds(geojsonObject.getBounds());
    // console.log(geojsonObject);
    // end debugging

    return <GeoJSON data={data} />;
  } else {
    return null;
  }
};

// function RenderFunc(agri) {
//   useEffect(() => {
//     if (agri.hasOwnProperty("agri")) {
//       console.log(agri.features[0].geometry.coordinates[0], "agri");
//     }
//   }, [agri]);
// }
const bounds = new LatLngBounds([40.712216, -74.22655], [40.773941, -74.12544])

function MapComponent({ agri, id, agri1, ...props }) {
  const { userRole } = useContext(UserCredsContext);
  const [open1, setOpen1] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [formType, setFormType] = useState("chform1");
  const [mapData, setMapData] = useState([]);
  const [mapData1, setMapData1] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [formLoading, setFormLoading] = useState({});
  // var hello = GeometryUtil.closest;
  useEffect(() => {
    if (agri.hasOwnProperty("features")) {
      var myMap = [];
      for (var i = 0; i < agri.features.length; i++) {
        var reverseArray = [];
        // new Array(agri.features.length)
        console.log(
          agri.features[i].geometry.coordinates[0][0],
          "agri.features[i].geometry.coordinates"
        );

        var newClone = JSON.parse(
          JSON.stringify(agri.features[i].geometry.coordinates[0])
        );
        const clone = reverseCoordinates(newClone[0]);
        console.log(clone, "clone");
        // clone.map((item) => {
        //   console.log(item,'item.reverse()')
        //   reverseArray.push(item.reverse());
        //   console.log(item.reverse(), item, "polygon");
        // });

        // var newarrays = agri.features[i].geometry.coordinates[0]
        //   .slice()
        //   .reverse();

        // console.log(reverseCoordinates(agri.features[i].geometry.coordinates[0]),'newarrays')
        var currentMap = {
          properties: agri.features[i].properties,
          coordinates: clone,
        };
        myMap.push(currentMap);
      }
      setMapData(myMap);
    }
    if (agri1.hasOwnProperty("features")) {
      var myMap = [];
      for (var i = 0; i < agri1.features.length; i++) {
        var reverseArray = [];
        // new Array(agri.features.length)
        console.log(
          agri1.features[i].geometry.coordinates[0][0],
          "agri.features[i].geometry.coordinates"
        );

        var newClone = JSON.parse(
          JSON.stringify(agri1.features[i].geometry.coordinates[0])
        );
        const clone = reverseCoordinates(newClone);
        console.log(clone, "clone");
        // clone.map((item) => {
        //   console.log(item,'item.reverse()')
        //   reverseArray.push(item.reverse());
        //   console.log(item.reverse(), item, "polygon");
        // });

        // var newarrays = agri.features[i].geometry.coordinates[0]
        //   .slice()
        //   .reverse();

        // console.log(reverseCoordinates(agri.features[i].geometry.coordinates[0]),'newarrays')
        var currentMap = {
          properties: agri1.features[i].properties,
          coordinates: clone,
        };
        myMap.push(currentMap);
      }
      setMapData1(myMap);
    }
  }, [agri, agri1]);

  const handleForm = (_item) => {
    if (userRole.type === "admin") {
      setOpen1(true);
    }
  };

  const handleOpenForm = (_boolean, _type) => {
    setOpen2(_boolean);
    setFormType(_type);
  };
  function submitIssue(_type) {
    const data = {
      TicketType: _type,
      title: "titles1",
      user: 1,
      index: 1,
      description: "description",
    };
    api_token
      .post(`/geo/map/v1/raise/issue/?plot_id=${id}`, data)
      .then((response) => {})
      .catch((error) => {});
  }
  return (
    <div style={{ width: "100%", height: "100%" }}>
      {/* {RenderFunc(agri)} */}
      <MapContainer
        center={[25.792077675732713, 83.774359934639861]}
        zoom={15}
        maxZoom={30}
        scrollWheelZoom={false}
        style={{ width: "100%", height: "100%" }}
      >
        <ImageOverlay
          url="http://www.lib.utexas.edu/maps/historical/newark_nj_1922.jpg"
          bounds={bounds}
          opacity={0.5}
          zIndex={10}
        />
        {/* <ImageOverlay url="https://i.imgur.com/Ion6X7C.jpg" 
        center={[25.792077675732713, 83.774359934639861]}
        zoom={15}
        /> */}
        {/* <MyData agri={agri} /> */}
        <LayersControl position="topright">
          {/* <LayersControl.Overlay checked name="Layer group with circles">
            <LayerGroup>
              <Circle
                center={center}
                pathOptions={{ fillColor: "blue" }}
                radius={200}
              />
              <Circle
                center={center}
                pathOptions={{ fillColor: "red" }}
                radius={100}
                stroke={false}
              />
              <LayerGroup>
                <Circle
                  center={[51.51, -0.08]}
                  pathOptions={{ color: "green", fillColor: "green" }}
                  radius={100}
                />
              </LayerGroup>
            </LayerGroup>
          </LayersControl.Overlay> */}
          <LayersControl.Overlay checked name="Water">
            {/* <ImageMapLayer
              url="https://landsat.arcgis.com/arcgis/rest/services/Landsat/PS/ImageServer"
              attribution="United States Geological Survey (USGS), National Aeronautics and Space Administration (NASA)"
            /> */}
            <FeatureGroup pathOptions={{ color: "blue" }}>
              <Popup>Popup in FeatureGroup</Popup>
              {/* <Circle center={[51.51, -0.06]} radius={200} />
              <Rectangle
                bounds={rectangle}
                eventHandlers={{
                  click: () => {
                    console.log("marker clicked");
                  },
                }}
              /> */}
              {mapData.map((item, index) => {
                return (
                  <Polygon
                    pathOptions={purpleOptions}
                    positions={item.coordinates}
                    eventHandlers={{
                      click: () => {
                        // handleForm(item);
                      },
                    }}
                  />
                );
              })}
            </FeatureGroup>
            <LayersControl.Overlay checked name="Road">
              <FeatureGroup pathOptions={{ color: "green" }}>
                {mapData1.map((item, index) => {
                  return (
                    <Polyline
                      pathOptions={redOptions}
                      positions={item.coordinates}
                    />
                  );
                })}
              </FeatureGroup>
            </LayersControl.Overlay>
          </LayersControl.Overlay>
        </LayersControl>
        {/* https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png */}
        {/* https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png */}
        {/* https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x} */}
        <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}" />
      </MapContainer>
      <CustomDialog
        _open={open1}
        _setOpen={setOpen1}
        handleOpenForm={handleOpenForm}
      />
      <CustomDrawer
        anchor="right"
        _open={open2}
        _setOpen={setOpen2}
        formType={formType}
      >
        {formType == "chform1" && (
          <>
            <div className={styles.formHeader}>
              <h2> CH-Form1</h2>
              <h3>See Rule 97</h3>
              <p>Khatauni prepared under section 27 of the Act</p>
            </div>
            <div>
              {chform1.map((item, index) => {
                const { name } = item;
                let label = name[0].toUpperCase() + name.slice(1);
                return (
                  <CustomInput
                    style={{ width: "90%", margin: "10px 0px" }}
                    name={item.name}
                    label={label}
                  />
                );
              })}
              <div className={styles.bottomButton}>
                <Button
                  variant="contained"
                  style={{ marginRight: "10px" }}
                  onClick={() => setOpen2(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  onClick={() => {
                    submitIssue("type1");
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </>
        )}
        {formType == "chform2" && (
          <>
            <div className={styles.formHeader}>
              <h2> CH-Form2</h2>
              {/* <h3>See Rule 97</h3> */}
              <p>Khatauni prepared under section 27 of the Act</p>
            </div>
            <div>
              {chform2.map((item, index) => {
                const { name } = item;
                let label = name[0].toUpperCase() + name.slice(1);
                return (
                  <CustomInput
                    style={{ width: "90%", margin: "10px 0px" }}
                    name={item.name}
                    label={label}
                  />
                );
              })}
              <div className={styles.bottomButton}>
                <Button
                  variant="contained"
                  style={{ marginRight: "10px" }}
                  onClick={(() => setOpen2(false), submitIssue("type2"))}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  onClick={() => {
                    submitIssue("type1");
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </>
        )}
      </CustomDrawer>
    </div>
  );
}

export default MapComponent;
