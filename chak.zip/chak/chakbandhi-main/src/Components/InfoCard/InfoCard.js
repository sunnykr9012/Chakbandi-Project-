import React from "react";
import styles from "./InfoCard.module.css";
import { Link } from "react-router-dom";

function InfoCard({ _data, key, type, ...props }) {
  console.log(_data,'_data')
  return (
    <div className={styles.cardContainer} key={key}>
      <div className={styles.upperSection}>
        <div className={styles.infoText}>
          <div className={styles.areaSection}>
            <p>Total Area</p>
            <p>
              <span className={styles.boldFontStyle}>0.234 </span>hectare
            </p>
          </div>
        </div>
        <div className={styles.infoSection}>
          <div>
            <p>
              Owner:
              <span className={styles.boldFontStyle}>{_data?.owner}</span>
            </p>
            <p>
              Gaurdian:
              <span className={styles.boldFontStyle}>{_data?.gaurdian}</span>
            </p>
          </div>
          <div>
            <p>
              District:
              <span className={styles.boldFontStyle}>
                {" "}
                {_data?.district?.title}
              </span>
            </p>
            <p>
              Tehsil:
              <span className={styles.boldFontStyle}>
                {" "}
                {_data?.tehsil?.title}
              </span>
            </p>
            <p>
              Village:
              <span className={styles.boldFontStyle}> {_data?.village?.title}</span>
            </p>
            <p>
              Plot No:
              <span className={styles.boldFontStyle}>
                {" "}
                {_data?.new_plot_number}
              </span>
            </p>
            <p>
              Kasra No:
              <span className={styles.boldFontStyle}> {_data?.kasra_no}</span>
            </p>
          </div>
        </div>
        {/* {type === 2 && (
          <div className={styles.infoText} style={{ marginLeft: "auto" }}>
            <div className={styles.areaSection}>
              <p style={{ margin: "5px 0px" }}>Current Status</p>
              <p style={{ margin: "5px 0px" }}>
                <span className={styles.boldFontStyle}>Settled </span>
              </p>
            </div>
          </div>
        )} */}
      </div>
      <div className={styles.bottomSection}>
        <div>
          {/* <p className={styles.dateS}>{_data?.modified_at}</p> */}
        </div>
        {type === 1 && (
          <div className={styles.buttonSection}>
            <p style={{ cursor: "pointer" }}>
              <span className={styles.boldFontStyle}>View history</span>
            </p>
            <Link to={`/dashboard/my-land-parcel/${_data?.id}`}>
              <p style={{ cursor: "pointer" }}>
                <span className={styles.boldFontStyle}>View Map</span>
              </p>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

export default InfoCard;
