import React from "react";
import styles from "./index.module.css";
import upgovLogo from "../../Assets/lekhpal/upgov.png";
import userLogo from "../../Assets/lekhpal/userloged.png";
import Logout from "../Logout.js/Logout";

const LekhpalHeader = () => {
  return (
    <>
      <div className={styles.headerBox}>
        <div>
          <img src={upgovLogo} alt="up gov" width="280px" />
        </div>
        <div>
          <img src={userLogo} alt="user" />
          <Logout />
        </div>
      </div>
    </>
  );
};

export default LekhpalHeader;
