import { Button } from "@mui/material";
import React from "react";
import { useContext } from "react";
import { UserCredsContext } from "../../ContextApi/UserCredsContext/UserCredsContext";

const Logout = () => {
  const { logout } = useContext(UserCredsContext);
  return (
    <div>
      <Button size="small" variant="contained" onClick={() => logout()}>
        Logout
      </Button>
    </div>
  );
};

export default Logout;
