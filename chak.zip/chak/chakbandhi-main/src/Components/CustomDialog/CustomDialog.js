import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import styles from "./CustomDialog.module.css";

export default function CustomDialog({
  _open,
  _setOpen,
  handleOpenForm,
  ...props
}) {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    setOpen(_open);
  }, [_open]);

  const handleClose = () => {
    setOpen(false);
    _setOpen(false);
  };

  const handleChange = (_boolean, _type) => {
    handleOpenForm(_boolean, _type);
    _setOpen(false);
  };

  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">Select one form</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <div className={styles.dialogContainer}>
              <Button
                variant="contained"
                style={{ marginRight: "20px" }}
                onClick={() => handleChange(true, "chform1")}
              >
                CH-Form1
              </Button>
              <Button
                variant="contained"
                onClick={() => handleChange(true, "chform2")}
              >
                CH-Form2
              </Button>
            </div>
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
}
