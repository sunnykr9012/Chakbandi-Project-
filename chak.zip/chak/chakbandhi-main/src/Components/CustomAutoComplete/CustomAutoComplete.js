import React from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";

const CustomAutoComplete = ({ value, onChange, options }) => {
  // const options = ["Option 1", "Option 2", "Option 3", "Option 4", "Option 5"];

  return (
    <Autocomplete
      options={options || []}
      value={value}
      onChange={onChange}
      getOptionLabel={(option) => option.title} // Display the title in the Autocomplete
      size="small"
      renderInput={(params) => <TextField {...params} />}
      renderOption={(
        props,
        option // Customize how options are displayed
      ) => <li {...props}>{option.title}</li>}
    />
  );
};

export default CustomAutoComplete;

// Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
