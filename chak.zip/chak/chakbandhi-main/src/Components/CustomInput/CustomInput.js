import { TextField } from "@mui/material";
import React from "react";

function CustomInput({
  size = "small",
  style = {},
  ...props
}) {
  return (
    <React.Fragment>
      <TextField
        size={size}
        style={style}
        {...props}
      />
    </React.Fragment>
  );
}

export default CustomInput;
