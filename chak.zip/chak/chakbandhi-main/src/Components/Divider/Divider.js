import React from "react";

const Divider = () => {
  return <div style={{ borderBottom: "1.5px solid gray" , marginTop:"5px" }}></div>;
};

export default Divider;
