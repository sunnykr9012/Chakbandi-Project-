import React, { useContext } from "react";
import styles from "./Header.module.css";
import Avatar from "@mui/material/Avatar";
import { UserCredsContext } from "../../ContextApi/UserCredsContext/UserCredsContext";

function Header() {
  const { userState } = useContext(UserCredsContext);
  return (
    <div className={styles.headerContainer}>
      <div></div>
      <div className={styles.headerFlexC}>
        <Avatar style={{ background: "#585858", marginRight: "10px" }}>
          {userState?.username.charAt(0).toUpperCase()}
        </Avatar>
        <p>{userState?.username}</p>
      </div>
    </div>
  );
}

export default Header;
