import React, { useEffect, useState } from "react";
import styles from "./LandParcel.module.css";
import InfoCard from "../../Components/InfoCard/InfoCard";
import CustomAutoComplete from "../../Components/CustomAutoComplete/CustomAutoComplete";
import CustomInput from "../../Components/CustomInput/CustomInput";
import {
  districtOptions,
  tehsilOptions,
  villageOptions,
} from "../../Utils/constants";
import { api_token } from "../../Utils/Network";

function LandParcel(props) {
  const [landList, setLandList] = useState([]);
  useEffect(() => {
    getData();
  }, []);
  function getData() {
    api_token
      .get(`/geo/map/v1/plot/`)
      .then((response) => {
        setLandList(response.data.data);
      })
      .catch((error) => {});
  }
  console.log(landList, "landList");
  return (
    <div>
      <div style={{ display: "flex", marginBottom: "20px" }}>
        <div className={styles.filtersC}>
          <CustomAutoComplete
            label="District"
            options={districtOptions}
            value={{ title: "Ghazipur", id: 1 }}
          />
        </div>
        <div className={styles.filtersC}>
          <CustomAutoComplete
            label="Tehsil"
            options={tehsilOptions}
            value={{ title: "Mohammadabad", id: 2 }}
          />
        </div>
        <div className={styles.filtersC}>
          <CustomAutoComplete
            label="Village"
            options={villageOptions}
            value={{ title: "Sherpur Dhotari", id: 3 }}
          />
        </div>
        <div className={styles.filtersC}>
          <CustomInput style={{ width: "250px" }} label="Plot no" />
        </div>
        <div className={styles.filtersC}>
          <CustomInput style={{ width: "250px" }} label="Plot no" />
        </div>
      </div>
      {landList.map((item, index) => {
        return <InfoCard type={1} _data={item} key={index} />;
      })}
      {/* <InfoCard type={1} /> */}
    </div>
  );
}

export default LandParcel;
