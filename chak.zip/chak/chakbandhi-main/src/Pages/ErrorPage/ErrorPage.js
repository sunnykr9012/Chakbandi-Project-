import React from "react";

function ErrorPage() {
  return <div>Comming Soon....</div>;
}

export default ErrorPage;
