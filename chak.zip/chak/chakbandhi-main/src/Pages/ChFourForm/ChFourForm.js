import React, { useState } from "react";
import styles from "./index.module.css";
import CustomSelect from "../../Components/CustomSelect/CustomSelect";
import Divider from "../../Components/Divider/Divider";
import InputFields from "../../Components/InputFields/InputFields";
import { form4Fields } from "../../Utils/lekphpalConstants";
import { form4initialState, formFourReducer } from "./formFourReducer";
import { useReducer } from "react";
import { Button } from "@mui/material";
import { api_call_token } from "../../Utils/Network2";
import { api_token } from "../../Utils/Network";
import CustomAutoComplete from "../../Components/CustomAutoComplete/CustomAutoComplete";

const ChFourForm = () => {
  const [state, dispatch] = useReducer(formFourReducer, form4initialState);
  const [allList, setAllList] = useState({
    allDistricts: [{ id: 3, title: "Ghazipur" }],
    allTehsils: [{ id: 12, title: "Mohammadabad" }],
    allVillages: [{ id: 7, title: "Sherpur Dhotari" }],
  });

  const handleChangeAutoComplete = (value, fieldType) => {
    console.log("FieldsTypeeee", value, fieldType);
    // setSelectType(fieldType);
  };

  const handleForm4aSubmit = () => {
    console.log("FInalstate", state);
    state.district_id = 3;
    state.tahsil_id = 12;
    state.village_id = 7;
    state.plot_id = 1;
    state.nature = "dsjdhj";
    state.index = 1;
    api_token
      .post(`geo/map/v1/4a/form/`, state)
      .then((response) => {
        alert("Form Submitted")
      })
      .catch((err) => {
        console.log(err);
        alert("Error!!");
      });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {form4Fields?.firstSection?.map((field, index) => {
        return (
          <div key={index} className={styles.fieldMarginBottom}>
            <span>{field?.title}</span>
            {field?.fieldType === 1 && (
              <InputFields
                value={state?.keyname}
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            )}
            {field?.fieldType === 2 && (
              <CustomSelect
                value={state?.keyname}
                listArray={allList[field?.options]}
              />
            )}
            {field?.fieldType === 3 && (
              <CustomAutoComplete
                value={state?.keyname}
                options={allList[field?.options]}
                onChange={(e, val) => {
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: val,
                  });
                  handleChangeAutoComplete(val, field?.keyname);
                }}
              />
            )}
          </div>
        );
      })}

      <Divider />
      <div style={{ marginTop: "17px" }}>
        {form4Fields?.secondSection?.map((field, index) => {
          return (
            <div className={styles.fieldMarginBottom}>
              <div>{field?.title}</div>
              <InputFields
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            </div>
          );
        })}
      </div>

      <div>
        {form4Fields?.disputeDetails?.map((field, index) => {
          return (
            <div className={styles.fieldMarginBottom}>
              <div>{field?.title}</div>
              <InputFields
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            </div>
          );
        })}
      </div>

      <div>
        {form4Fields?.thirdsection?.map((field, index) => {
          return (
            <div className={styles.fieldMarginBottom}>
              <div>{field?.title}</div>
              <InputFields
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            </div>
          );
        })}
      </div>

      <div style={{ width: "100%", marginBottom: "20px" }}>
        <Button
          sx={{ width: "100%" }}
          variant="contained"
          onClick={handleForm4aSubmit}
        >
          Submit
        </Button>
      </div>
    </div>
  );
};

export default ChFourForm;
