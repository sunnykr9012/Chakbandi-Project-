import React, { useEffect, useState } from "react";
import CustomSelect from "../../Components/CustomSelect/CustomSelect";
import InputFields from "../../Components/InputFields/InputFields";
import styles from "./index.module.css";
import Divider from "../../Components/Divider/Divider";
import { form2AinitialState } from "./formTwoReducer";
import { useReducer } from "react";
import { formTwoReducer } from "./formTwoReducer";
import { Button } from "@mui/material";
import { api_call_token } from "../../Utils/Network2";
import { form2AFields } from "../../Utils/lekphpalConstants";
import CustomAutoComplete from "../../Components/CustomAutoComplete/CustomAutoComplete";
import { UserCredsContext } from "../../ContextApi/UserCredsContext/UserCredsContext";
import { useContext } from "react";
import { api_token } from "../../Utils/Network";
import BackBtn from "../../Components/BackBtn/BackBtn";

const ChTwoForm = () => {
  const { districtList, tehsilList, villageList } =
    useContext(UserCredsContext);
  const [state, dispatch] = useReducer(formTwoReducer, form2AinitialState);
  const [selectType, setSelectType] = useState("");
  // const [districtList, setDistrictList] = useState([]);
  // const [tehsilList, setTehsilList] = useState([]);
  // const [villageList, setVillageList] = useState([]);
  const [allList, setAllList] = useState({
    allDistricts: [{ id: 3, title: "Ghazipur" }],
    allTehsils: [{ id: 12, title: "Mohammadabad" }],
    allVillages: [{ id: 7, title: "Sherpur Dhotari" }],
  });

  // useEffect(() => {
  //   setAllList({
  //     ...allList,
  //     allDistricts: districtList,
  //     allTehsils: tehsilList,
  //     allVillages: villageList,
  //   });
  // }, [districtList.length, tehsilList.length, villageList.length]);

  console.log("HGHGH", districtList, tehsilList, villageList);

  console.log("STATEDISTRICT", allList);

  const handleChangeAutoComplete = (value, fieldType) => {
    console.log("FieldsTypeeee", value, fieldType);
    setSelectType(fieldType);
  };

  const handleForm2aSubmit = () => {
    console.log("FInalstate", state);

    state.district_id = 3;
    state.tahsil_id = 12;
    state.village_id = 7;
    state.plot_id = 1;
    state.nature = "dsjdhj";
    state.index = 1;
    api_token
      .post(`geo/map/v1/2a/form/`, state)
      .then((response) => {
        alert("Form Submitted.");
      })
      .catch((err) => {
        console.log(err);
        alert("Error!!");
      });
  };

  // useEffect(() => {
  //   // callTehsilApi();
  //   if (selectType === "district") {
  //     setAllList({
  //       ...allList,
  //       allTehsils: setThlist,
  //     });
  //   } else if (selectType === "tehsil") {
  //     setAllList({
  //       ...allList,
  //       allVillages: setVList,
  //     });
  //   }
  // }, [selectType]);

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {/* Select first section  */}

      {/* <div className={styles.fieldMarginBottom}>
        <BackBtn />
      </div> */}

      <div className={styles.fieldMarginBottom}>
        <span>State</span>
        <CustomSelect listArray={[]} label="Uttar Pradesh" disabled={true} />
      </div>

      {form2AFields?.firstSection?.map((field, index) => {
        return (
          <div key={index} className={styles.fieldMarginBottom}>
            <span>{field?.title}</span>
            {field?.fieldType === 1 && (
              <InputFields
                value={state?.keyname}
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            )}
            {field?.fieldType === 2 && (
              <CustomSelect
                value={state?.keyname}
                listArray={allList[field?.options]}
              />
            )}
            {field?.fieldType === 3 && (
              <CustomAutoComplete
                value={state?.keyname}
                options={allList[field?.options]}
                onChange={(e, val) => {
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: val,
                  });
                  handleChangeAutoComplete(val, field?.keyname);
                }}
              />
            )}
          </div>
        );
      })}
      <Divider />
      {/* 9 */}
      <div>
        <p className={styles.mainLabel}>Area</p>
        {/* <div className={styles.fieldMarginBottom}>
          <span>Plot No.</span>
          <InputFields name="basic_khasra_rec" />
        </div> */}

        {form2AFields?.area1.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>
              <InputFields
                value={state?.keyname}
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 10 */}
      <div>
        <p className={styles.mainLabel}>
          No. of Khata Khatauni of the basic year
        </p>

        {form2AFields?.khata_Khatauni_basic_year.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>
              <InputFields
                name={field?.keyname}
                onChange={(e) =>
                  dispatch({
                    type: "field",
                    fieldName: field?.keyname,
                    payload: e.target.value,
                  })
                }
              />
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 18 */}
      <div>
        <p className={styles.mainLabel}>
          Details of improvements, if any, like a well, tube-well, etc. existing
          in the plot or trees other than those constituting a grove standing in
          the plot or on its boundaries
        </p>
        {form2AFields?.details_improvments.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 20 */}
      <div>
        <p className={styles.mainLabel}>
          Details of groves existing in the agricultural year Immediately
          preceding the year in which notification under Section 4 was issued
        </p>
        {form2AFields?.groove_details.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />

      {/* 23 */}
      <div>
        <p className={styles.mainLabel}>Details of uncultivated area</p>
        {form2AFields?.details_uncultivated_area.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 25 */}
      <div>
        <p className={styles.mainLabel}>Details of irrigation</p>
        {form2AFields?.irrigation_details.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 28 */}
      <div>
        <p className={styles.mainLabel}>Crops generally grown during</p>
        {form2AFields?.crops_grown.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />
      {/* 30 */}
      <div style={{ marginTop: "17px" }}>
        {form2AFields?.unidentified_labels_1.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>

      <Divider />
      {/* 32 */}
      <div>
        <p className={styles.mainLabel}>Area</p>
        {form2AFields?.area_consolidation.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />

      <div style={{ marginTop: "17px" }}>
        {form2AFields?.unidentified_labels_2.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>
      <Divider />

      {/* 36 */}

      {/* 39 */}
      <div>
        <p className={styles.mainLabel}>
          Khata No. of C.H Form 23 to which allotted with area/valuation if
          partly allotted
        </p>
        {form2AFields?.khata_valuation_last.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>

      <Divider />

      <div style={{ marginTop: "17px" }}>
        {form2AFields?.last_section.map((field, index) => {
          return (
            <div key={index} className={styles.fieldMarginBottom}>
              <span>{field?.title}</span>

              {field?.fieldType === 1 && (
                <InputFields
                  value={state?.keyname}
                  name={field?.keyname}
                  onChange={(e) =>
                    dispatch({
                      type: "field",
                      fieldName: field?.keyname,
                      payload: e.target.value,
                    })
                  }
                />
              )}
            </div>
          );
        })}
      </div>

      <div style={{ width: "100%", marginBottom: "20px" }}>
        <Button
          sx={{ width: "100%" }}
          variant="contained"
          onClick={handleForm2aSubmit}
        >
          Submit
        </Button>
      </div>
    </div>
  );
};

export default ChTwoForm;

const setThlist = [
  {
    id: 1,
    title: "Th1",
  },
  {
    id: 2,
    title: "Th2",
  },
  {
    id: 3,
    title: "Th3",
  },
];

const setVList = [
  {
    id: 1,
    title: "V1",
  },
  {
    id: 2,
    title: "V2",
  },
  {
    id: 3,
    title: "V3",
  },
];
