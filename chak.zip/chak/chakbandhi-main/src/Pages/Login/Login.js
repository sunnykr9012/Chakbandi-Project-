import React, { useContext, useState } from "react";
import styles from "./Login.module.css";
import { Button, TextField } from "@mui/material";
import ValidateOTP from "../../Components/ValidateOTP/ValidateOTP";
import { api_open, setToken } from "../../Utils/Network";
import { UserCredsContext } from "../../ContextApi/UserCredsContext/UserCredsContext";
import { useNavigate } from "react-router-dom";
function Login(props) {
  const { setUserState } = useContext(UserCredsContext);
  const navigate = useNavigate();
  const [formData, setFormData] = React.useState({
    mobile: "",
    otp: "",
    token: "",
    username: "drone_geo",
    password: "drone",
  });

  const [step, setStep] = useState(1);
  const [error, setError] = React.useState({
    phone: "",
    otp: "",
    token: "",
    username: "",
    password: "",
  });
  const handleOTP = (_array) => {
    setError({ phone: "", otp: "", field: "" });
    var otpString = parseInt(_array.join(""));
    var otp = parseInt(otpString);
    setFormData({ ...formData, otp: `${otp}` });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  function generateOtp() {
    return (
      <div>
        {/* <p className={styles.headText}>Enter your username and password</p> */}
        <div className={styles.indentsecondary}>
          {/* <p className={styles.secondary_text} style={{ color: "grey" }}>
            We will not share your number without your permission
          </p> */}
          <div>
            <div style={{ marginBottom: "25px" }}>
              <TextField
                size="small"
                style={{ width: "80%" }}
                name="username"
                value={formData.username}
                type="text"
                onChange={(e) => handleChange(e)}
                label="Username"
              />
              {error.username && (
                <p
                  style={{
                    margin: "5px auto",
                    textAlign: "left",
                    color: "red",
                    width: "80%",
                  }}
                >
                  {error.username}
                </p>
              )}
            </div>
            <TextField
              size="small"
              style={{ width: "80%" }}
              name="password"
              value={formData.password}
              type="password"
              onChange={(e) => handleChange(e)}
              label="Password"
            />
            {error.password && (
              <p
                style={{
                  margin: "5px auto",
                  textAlign: "left",
                  color: "red",
                  width: "80%",
                }}
              >
                {error.password}
              </p>
            )}
          </div>
          <div>
            <Button
              variant="contained"
              style={{ width: "80%", marginTop: "20px" }}
              onClick={() => handleLogin(1)}
              //   onClick={() => handleStep(1)}
            >
              Login
            </Button>
          </div>
          {/* <p style={{ color: "grey" }}>You will receive an OTP.</p> */}
        </div>
      </div>
    );
  }

  function validateOtp() {
    return (
      <div>
        {/* <p className={styles.headText}>Enter your phone number</p> */}
        <div className={styles.indentsecondary}>
          <p className={styles.secondary_text}>
            A 4 digit OTP have been sent to
          </p>
          <div style={{ width: "50%", margin: "20px auto" }}>
            <ValidateOTP handleOTP={handleOTP} />
          </div>
          <div>
            <Button
              variant="contained"
              style={{ width: "100%", marginTop: "20px" }}
              //   onClick={() => handleStep(2)}
            >
              verify
            </Button>
          </div>
          <p style={{ color: "grey" }}>
            Please verify the OTP to log in.
            <span
              className={styles.spanC}
              //   onClick={() => setCurrentStep(3)}
            >
              {/* Create account */}
            </span>
          </p>
        </div>
      </div>
    );
  }

  const handleLogin = () => {
    const data = {
      username: formData.username,
      password: formData.password,
    };
    api_open
      .post(`login/`, data)
      .then((response) => {
        console.log("LOGIN", response);
        const { access, refresh, user } = response.data.data;
        const token = {
          access,
          refresh,
        };

        console.log("TYpeSUSE", user);

        setUserState(user, token);
        localStorage.setItem("dd_chakbandi", JSON.stringify(user));
        setToken(access);
        // navigate(`/dashboard`);

        if (user?.user_type === 1) {
          navigate(`/lekhpal/forms`);
        } else if (user?.user_type === 2) {
          navigate(`/dashboard`);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className={styles.loginContainer}>
      <h1 style={{ textAlign: "center" }}>Chakbandhi</h1>
      <div>{step == 1 && generateOtp()}</div>
      <div>{step == 2 && validateOtp()}</div>
    </div>
  );
}

export default Login;
