import React from 'react';

function Feedback() {
    return (
        <div>
            feedback
        </div>
    );
}

export default Feedback;