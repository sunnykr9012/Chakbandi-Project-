import React from 'react';

function Tehsil(props) {
    return (
        <div>
            Tehsil
        </div>
    );
}

export default Tehsil;