import React from 'react';

function Register(props) {
    return (
        <div>
            register
        </div>
    );
}

export default Register;