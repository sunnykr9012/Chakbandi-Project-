import React from 'react';

function TestChForms(props) {
    return (
        <div>
            create your ch forms over here
        </div>
    );
}

export default TestChForms;

export const chform1 = [
    {
      name: "No. of Khata Khatauni of the basic year",
      id: 1,
      label: "no_of_khata_khatauni",
    },
    {
      name: "Plots Nos where mistakes and disputes do not relate to the whole Khata",
      id: 2,
      label: "plots_with_mistakes_disputes",
    },
    {
      name: "Area of plots recorded in Column 2",
      id: 3,
      label: "area_of_recorded_plots",
    },
    {
      name: "Details of mistakes and disputes discovered during the test and verification of the Khatauni and field to field partial",
      id: 4,
      label: "mistakes_disputes_details",
    },
    {
      name: "Serial No.",
      id: 5,
      label: "serial_number",
    },
    {
      name: "Details",
      id: 6,
      label: "details",
    },
    {
      name: "Details of shares claimed in the holding by each tenure-holder",
      id: 7,
      label: "claimed_shares_details",
    },
    {
      name: "Orders of Assistant Consolidation Officer in the case of clerical mistakes in Part I",
      id: 8,
      label: "aco_orders_clerical_mistakes",
    },
    {
      name: "Remark",
      id: 9,
      label: "remark",
    },
  ];

  

  export const chform2 = [
    {
      name: "village",
      id: 1,
      label: "village",
    },
    {
      name: "pargana",
      id: 2,
      label: "pargana",
    },
    {
      name: "tahsil",
      id: 3,
      label: "tahsil",
    },
    {
      name: "district",
      id: 4,
      label: "district",
    },
    {
      name: "serial_number",
      id: 5,
      label: "serial number",
    },
    {
      name: "khatauni_khata",
      id: 6,
      label: "khatauni khata",
    },
    {
      name: "tenure_holder",
      id: 7,
      label: "tenure holder",
    },
    {
      name: "new_plot_number",
      id: 8,
      label: "new plot number",
    },
    {
      name: "area",
      id: 9,
      label: "area",
    },
    {
      name: "input1",
      id: 10,
      label: "input 1",
    },
    {
      name: "input2",
      id: 1,
      label: "input 2",
    },
    {
      name: "reult",
      id: 10,
      label: "result",
    },
  ];
  