import React from "react";
import styles from "./index.module.css";
import { NavLink } from "react-router-dom";
import Divider from "../../Components/Divider/Divider";
import righArrow from "../../Assets/lekhpal/right-arrow 1.png";

const FormList = () => {
  return (
    <div className={styles.listContainer}>
      {formListing.map((form, index) => {
        return (
          <>
            <NavLink className={styles.navLink} to={`/lekhpal/${form?.key}`}>
              <div key={index} className={`${styles.listBox}`}>
                <span>{form?.title}</span>
                <span>{<img src={righArrow} alt="click" />}</span>
                {/* <span>{"=>"}</span> */}
              </div>
            </NavLink>
            <Divider />
          </>
        );
      })}
    </div>
  );
};

export default FormList;

const formListing = [
  {
    id: 1,
    title: "CH Form 2",
    key: "ch-2-form",
    status: "",
  },
  {
    id: 2,
    title: "CH Form 4",
    key: "ch-4-form",
    status: "",
  },
  {
    id: 3,
    title: "CH Form 5",
    status: "Comming Soon",
  },
  {
    id: 4,
    title: "CH Form 6",
    status: "Comming Soon",
  },
  {
    id: 5,
    title: "CH Form 7",
    status: "Comming Soon",
  },
];
