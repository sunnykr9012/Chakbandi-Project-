import React from 'react';

function CHForms() {
    return (
        <div>
            CHForms
        </div>
    );
}

export default CHForms;