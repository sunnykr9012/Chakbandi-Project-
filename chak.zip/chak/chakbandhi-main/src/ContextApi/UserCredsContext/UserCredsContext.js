import React, { Component, createContext } from "react";
import { createTheme } from "@mui/material/styles";
import { api_token } from "../../Utils/Network";
export const UserCredsContext = createContext();

// dd_chakbandi
const localstorage_state = localStorage.getItem("dd_chakbandi");

function getLocalData(keyname) {
  // Function to return values from local storage
  let object = null;
  try {
    object = JSON.parse(localstorage_state);
  } catch {
    console.error("There was error while parsing data from localstorage.");
  }

  if (object) {
    if (object[keyname]) {
      return object[keyname];
    }
  }

  if (keyname === "themeMode") return "light";

  if (keyname === "user_state") return {};
  if (keyname === "token") return { access: "", refresh: "" };
  return "";
}

class UserCredsContextProvider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      theme: createTheme({
        palette: {
          primary: { 500: "#212121" },
          secondary: { A400: "#e0e0e0" },
          white: { 500: "rgba(255,255,255)" },
          mode: "light",
        },
      }),
      userRole: { id: 1, type: "admin" },
      col: {
        primary: "#FB9B5F",
        secondary: "#143F6B",
        ternary: "#006080",
      },
      themeMode: getLocalData("themeMode"),
      user_state: getLocalData("user_state"),
      token: getLocalData("token"),
      districtList: [],
      tehsilList: [],
      villageList: [],
    };
    this.setThemeMode = this.setThemeMode.bind(this);
    this.setUserState = this.setUserState.bind(this);
    this.setToken = this.setToken.bind(this);
  }

  setAllLists = () => {
    console.log("ALLLIST", this.state.token);
    api_token
      .get(`base/v1/district/`)
      .then((res) => {
        let modifiedArray = res?.data?.data?.map((e) => {
          return {
            id: e?.id,
            title: e?.title,
          };
        });
        this.setState({ districtList: modifiedArray });
      })
      .catch((err) => {
        console.log(err);
      });
    api_token
      .get(`base/v1/tehils/`)
      .then((res) => {
        let modifiedArray = res?.data?.data?.map((e) => {
          return {
            id: e?.id,
            title: e?.title,
          };
        });

        this.setState({ tehsilList: modifiedArray });
      })
      .catch((err) => {
        console.log(err);
      });
    api_token
      .get(`base/v1/villages/`)
      .then((res) => {
        let modifiedArray = res?.data?.data?.map((e) => {
          return {
            id: e?.id,
            title: e?.title,
          };
        });
        this.setState({ villageList: modifiedArray });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  componentDidMount() {
    if (this.state.token?.access) {
      this.setAllLists();
    }

    return () => {
      localStorage.setItem("dd_chakbandi", JSON.stringify(this.state));
    };
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.user_state !== this.state.user_state) {
      localStorage.setItem("dd_chakbandi", JSON.stringify(this.state));
    }
  }

  componentWillUnmount() {}

  updateLocal = () => {
    localStorage.setItem("dd_chakbandi", JSON.stringify(this.state));
  };

  setThemeMode = (_boolean_value) => {};

  setUserState = (user_data, token_data) => {
    this.setState({ user_state: user_data, token: token_data }, () => {
      this.updateLocal();
    });
  };

  setToken = (_token) => {
    this.setState({ token: _token.token });
    this.updateLocal();
  };

  logout = () => {
    localStorage.clear();
    setTimeout(() => {
      window.location.href = "/";
    }, 500);
  };

  render() {
    return (
      <UserCredsContext.Provider
        value={{
          theme: this.state.theme,
          themeMode: this.state.themeMode,
          setUserState: this.setUserState,
          logout: this.logout,
          userState: this.state.user_state,
          token_data: this.state.token,
          setToken: this.setToken,
          userRole: this.state.userRole,
          districtList: this.state.districtList,
          tehsilList: this.state.tehsilList,
          villageList: this.state.villageList,
        }}
      >
        {this.props.children}
      </UserCredsContext.Provider>
    );
  }
}

export default UserCredsContextProvider;
