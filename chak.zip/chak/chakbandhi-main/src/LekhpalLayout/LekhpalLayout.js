import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import styles from "./index.module.css";

import { Box } from "@mui/material";
import LekhpalHeader from "../Components/LekhpalHeader/LekhpalHeader";
import BackBtn from "../Components/BackBtn/BackBtn";
// import Navbar from "../Component/Navbar/Navbar";
// import Footer from "../Component/Footer/Footer";
import { useLocation } from "react-router-dom";

function LekhpalLayout(props) {
  let location = useLocation();
  const [showBack, setShowBack] = useState(true);
  useEffect(() => {
    console.log("ppppp", location.pathname);

    if (location.pathname === "/lekhpal/forms") {
      setShowBack(false);
    } else {
      setShowBack(true);
    }
  }, [location.pathname]);

  return (
    <>
      <LekhpalHeader />
      <div className={styles.layoutContainer}>
        {showBack && (
          <div style={{ marginBottom: "10px"}}>
            <BackBtn />
          </div>
        )}

        <Outlet />
      </div>
    </>
  );
}

export default LekhpalLayout;
