import React, { useEffect } from "react";
import { NavLink, Outlet, useNavigate, useLocation } from "react-router-dom";
import styles from "./MainLayout.module.css";
import SidePanel from "../Components/SidePanel/SidePanel";
import Header from "../Components/Header/Header";
import { panelList } from "../Utils/constants";

function MainLayout(props) {
  let location = useLocation();
  let navigate = useNavigate();
  useEffect(() => {
    const { pathname } = location;
    if (pathname === "/dashboard") {
      navigate(`/dashboard/my-land-parcel`);
    }
  }, [location.pathname]);
  return (
    <div className={styles.layoutContainer}>
      <div className={styles.lFlexContainer}>
        <div className={styles.panelSection}>
          <SidePanel panelList={panelList}/>
        </div>
        <div className={styles.rightSection}>
          <Header />
          <div className={styles.layoutSection}>
            <Outlet />
            {/* <div>
              <p>
                <NavLink to="/dashboard">item 1</NavLink>
              </p>
              <p>
                <NavLink to="/dashboard/item2">item 2</NavLink>
              </p>
            </div>
            <div>
              <div style={{ margin: "15px" }}>
                <Outlet />
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainLayout;
