import "./App.css";
import MapComponent from "./Components/MapComponent";
import "leaflet/dist/leaflet.css";
import UserCredsContextProvider from "./ContextApi/UserCredsContext/UserCredsContext";
import Approuter from "./Approuter/Approuter";

function App() {
  return (
    <div className="App">
      <div style={{marginLeft:'auto'}}>
        <div id="google_translate_element"></div>
      </div>
      <UserCredsContextProvider>
        <Approuter />
      </UserCredsContextProvider>
      {/* <MapComponent /> */}
    </div>
  );
}

export default App;
